<!-- src/App.vue -->
<template>
  <router-view />
</template>

<script setup>
</script>

<style>
/* 可选：顶级过渡效果 */
</style>

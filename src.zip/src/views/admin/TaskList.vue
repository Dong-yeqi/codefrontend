<!-- src/views/TaskList.vue -->
<template>
  <MainLayout>
    <div class="card">
      <div
        style="
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 14px;
        "
      >
        <div class="section-title">爬虫任务列表</div>
        <button class="btn-ghost" @click="load">刷新</button>
      </div>

      <table class="table">
        <thead>
          <tr>
            <th>任务ID</th>
            <th>名称</th>
            <th>站点</th>
            <th>城市</th>
            <th>区域</th>
            <th>是否启用</th>
            <th>上次执行时间</th>
            <th style="text-align: right;">操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="task in tasks" :key="task.id">
            <td>{{ task.id }}</td>
            <td>{{ task.name }}</td>
            <td>{{ task.site }}</td>
            <td>{{ task.city }}</td>
            <td>{{ task.region }}</td>
            <td>
              <span
                class="tag"
                :class="task.enabled ? 'tag-success' : 'tag-failed'"
              >
                {{ task.enabled ? '启用' : '禁用' }}
              </span>
            </td>
            <td>{{ task.lastRunTime || '-' }}</td>
            <td style="text-align: right;">
              <button class="btn-ghost" style="margin-right: 6px;" @click="run(task)">
                执行
              </button>
              <button class="btn-ghost" style="border-color: #fecaca; color: #fecaca;"
                @click="remove(task)"
              >
                删除
              </button>
            </td>
          </tr>
          <tr v-if="!tasks.length">
            <td colspan="8" style="text-align: center; padding: 20px; color: #64748b;">
              暂无任务数据
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </MainLayout>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import MainLayout from '@/layouts/MainLayout.vue';
import { fetchTasks, runTask, deleteTask } from '@/api/task';

const tasks = ref([]);

async function load() {
  try {
    const data = await fetchTasks();
    tasks.value = data || [];
  } catch (e) {
    console.error(e);
    alert('加载任务失败');
  }
}

async function run(task) {
  if (!confirm(`确定要执行任务：${task.name} 吗？`)) return;
  try {
    await runTask(task.id);
    alert('任务已执行，稍后查看日志');
  } catch (e) {
    console.error(e);
    alert('执行失败');
  }
}

async function remove(task) {
  if (!confirm(`确定要删除任务：${task.name} 吗？`)) return;
  try {
    await deleteTask(task.id);
    await load();
  } catch (e) {
    console.error(e);
    alert('删除失败');
  }
}

onMounted(load);
</script>

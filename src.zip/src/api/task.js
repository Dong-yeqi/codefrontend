// src/api/task.js
import http from './http';

export function fetchTasks() {
  return http.get('/admin/crawl-task/list');
}

export function runTask(id) {
  return http.post(`/admin/crawl-task/run/${id}`);
}

export function deleteTask(id) {
  return http.post(`/admin/crawl-task/delete/${id}`);
}

// src/api/stats.js
import http from './http';

export function getStats() {
  // 后端自己对接：返回 { today, week, month, total, ... }
  return http.get('/stats/summary');
}

export function getPriceTrend() {
  return http.get('/stats/priceTrend');
}

export function getAreaDistribution() {
  return http.get('/stats/areaDistribution');
}

export function getLayoutDistribution() {
  return http.get('/stats/layoutDistribution');
}

export function getRegionBar() {
  return http.get('/stats/regionBar');
}

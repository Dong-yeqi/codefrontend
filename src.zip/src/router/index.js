// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router';

import Dashboard from '@/views/dashboard/Dashboard.vue';  // ✔ 实际存在
import TaskList from '@/views/admin/TaskList.vue';        // ✔ 实际存在
import Login from '@/views/admin/login.vue';              // ✔ login.vue 实际在 admin 目录

const routes = [
  { path: '/', redirect: '/dashboard' },
  { path: '/dashboard', component: Dashboard },
  { path: '/admin/tasks', component: TaskList },
  { path: '/admin/login', component: Login },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
